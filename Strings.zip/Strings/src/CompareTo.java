public class CompareTo {
	public static void main(String args[]){  
		String s1="hello";
		String s2="hello";
		String s3="hii";  
		String s4="welcome";  
		String s5="java";  
		 
		System.out.println(s1.compareTo(s2)); 
		System.out.println(s1.compareTo(s3));  
		System.out.println(s1.compareTo(s4));  
		System.out.println(s1.compareTo(s5));  
		}}  


