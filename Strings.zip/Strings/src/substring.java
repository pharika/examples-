
public class substring {  
	public static void main(String args[]){  
		String s1="hello";  
		System.out.println(s1.substring(2,4));
		System.out.println(s1.substring(2));

}
}
