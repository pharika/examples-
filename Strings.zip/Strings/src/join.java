
public class join {
		public static void main(String args[]){  
		String joinString1=String.join("-","welcome","to","java");
		System.out.println(joinString1); 
		System.out.println("\n"); 
		 String date = String.join("/","25","06","2018");    
	        System.out.print(date);    
		  
		}}  


