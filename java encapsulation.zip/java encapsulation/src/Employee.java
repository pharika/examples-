class Example{
    private int empno;
    private String empName;
    private int empAge;

    
    public int getEmpno(){
        return empno;
    }

    public String getEmpName(){
        return empName;
    }

    public int getEmpAge(){
        return empAge;
    }

    public void setEmpAge(int newValue){
        empAge = newValue;
    }

    public void setEmpName(String newValue){
        empName = newValue;
    }

    public void setEmpno(int newValue){
        empno = newValue;
    }
}
public class Employee{
    public static void main(String args[]){
         Example obj = new Example();
         obj.setEmpName("hari");
         obj.setEmpAge(21);
         obj.setEmpno(1234);
         System.out.println("Employee Name: " + obj.getEmpName());
         System.out.println("Employee empno: " + obj.getEmpno());
         System.out.println("Employee Age: " + obj.getEmpAge());
    } 
}