
public class whileloop {
	
	public static void main(String args[])
	{
	int i = 5;
	while (i <= 15)
	{
	System.out.println(i);
	i = i+2;
	}
	}
	}


