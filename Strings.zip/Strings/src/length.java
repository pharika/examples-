
public class length {
	 
		public static void main(String args[]){  
		String s1="hello";  
		String s2="java";  
		System.out.println("string length is: "+s1.length()); 
		System.out.println("string length is: "+s2.length());  
		}}  
		
