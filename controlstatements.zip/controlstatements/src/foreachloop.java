
public class foreachloop {
	
		public static void main(String args[]){
		int s[] = {18,25,28,29,30};
		for (int i : s) {
		System.out.println(i);
		}
		}
		}


