class example
{
    public void disp(char c)
    {
         System.out.println(c);
    }
    public void disp(char c, int num)  
    {
         System.out.println(c + " "+num);
    }
}
class Sample
{
   public static void main(String args[])
   {
       example obj = new example();
       obj.disp('a');
       obj.disp('a',10);
   }
}

