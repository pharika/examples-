abstract class Bird{
   
   public abstract void sound();
}

public class Parrot extends Bird{

   public void sound(){
	System.out.println("squqks");
   }
   public static void main(String args[]){
	Bird obj = new Parrot();
	obj.sound();
   }
}

