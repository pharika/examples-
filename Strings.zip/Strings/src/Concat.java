
public class Concat {
	  public static void main(String args[]){  
		String s1="hello";  
		s1.concat("welcome");  
		System.out.println(s1);  
		s1=s1.concat(" welcome to  java string");  
		System.out.println(s1);  

}
}
