
public class replace {
	  public static void main(String args[]){  
		String s1="hello welcome to java";  
		String replaceString=s1.replace('a','e');  
	    System.out.println(replaceString);
}
}
