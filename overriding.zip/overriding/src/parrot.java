class Bird{
   
   public void eat()
   {
      System.out.println("Bird is eating");
   }
}
class Parrot extends Bird{
   
   public void eat(){
      System.out.println("parrot is eating");
   }
   public static void main( String args[]) {
      Parrot obj = new Parrot();
      
      obj.eat();
   }
   }