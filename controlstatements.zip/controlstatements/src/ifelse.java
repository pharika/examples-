
public class ifelse {
	
	public static void main(String args[])
	{
	int a = 15;
	if (a > 20)
	System.out.println("a is greater than 10");
	else
	System.out.println("a is less than 10");
	System.out.println("Hello World!");
	}
	}
	


